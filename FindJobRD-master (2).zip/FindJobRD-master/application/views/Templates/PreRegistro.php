<h1>Seleccione el tipo de registro</h1>
</br>
</br>
<div>
<h4 align="center" > <b> Al registrarse como empresa tendra las siguientes opciones </b> </h4>
</br>
<li align="center">Podrá publicar las vacantes disponibles que posea</li>
</br>
<li align="center">Podrá buscar entre miles de candidatos el que mas se ajuste a lo que busca</li>
</div>
</br>

<div class="text-center">
  <a type="submit" class="btn btn-primary" href="<?php echo base_url('RegistroEmpresa/RegistroEmpresa'); ?>"  >Empresa</a>
</div>

</br>



<h4 align ="center"><b> Al registrarse como postulante tendra las siguientes opciones: </b></h4>
</br>
<li align="center">Podrá publicar sus habilidades para que las empresas observen si aplica a uno de sus puestos</li>
</br>
<li align="center">Podrá buscar entre cientas de vacantes disponibles la que mas que mas se ajuste a las habilidades que posea</li>
</br>
  <div class="text-center">
    <a type="submit" class="btn btn-primary" href="<?php echo base_url('/Formularios/RegistroCandidato'); ?>" >Postulante</a>
  </div>



<br/>





<br/>
