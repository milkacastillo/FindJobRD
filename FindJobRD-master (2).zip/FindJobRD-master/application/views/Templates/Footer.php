<div class="footer-area">
    <div class="container">
        <div class="row footer">
            <div class="col-md">
                <div class="single-footer">
                    <h4>Información</h4>
                    <div class="footer-links">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo base_url('/Home/Nosotros'); ?>">Nosotros</a></li>
                            <li><a href="<?php echo base_url('/Home/Servicios'); ?>" class="active">Servicios</a></li>
                            <li><a href="<?php echo base_url('/Home/Ayuda'); ?>">Ayuda</a></li>
                            <li><a href="<?php echo base_url('/Home/Contacto'); ?>">Contacto</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row footer-copy">
            <p><span>&copy; Time Warriors, All rights reserved</span> | Developed by  <span><a href="https://www.facebook.com/yohanselfaustojesus.delacruzcaminero">FAUSTO</a></span>  <span> <a href="https://www.facebook.com/milkac.goris">MILKA</a></span> <span> <a href="https://www.facebook.com/franklin0724">FRANKLIN</a></span></p>
        </div>
    </div>
</div>





<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="assets/js/vendor/jquery-1.10.2.min.js"><\/script>')</script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url();?>assets/js/wow.js"></script>
<script src="<?php echo base_url();?>assets/js/main.js"></script>
</body>
</html>
