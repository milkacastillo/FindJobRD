<div class="" id="login-modal" tabindex="-1"  aria-labelledby="myModalLabel" aria-hidden="true" >
    	  <div class="modal-dialog">
				<div class="loginmodal-container">
					<h1>Acceso Usuario</h1><br>
				  <form Method="POST" action="<?php echo base_url('Login/login1') ?>">
					<input type="text" name="user" placeholder="Nombre de Usuario">
					<input type="password" name="pass" placeholder="Contraseña">
          <label class="radio-inline">
  <input type="radio" name="inlineRadioOptions" id="Candidato" value="option1"> Candidato
</label>
<label class="radio-inline">
  <input type="radio" name="inlineRadioOptions" id="Empresa" value="option2"> Empresa
</label>
					<input type="submit" name="login" class="login loginmodal-submit" value="Iniciar Sesión">
				  </form>

				  <div class="login-help">
					<a href="#">Registrarse</a> - <a href="#">Recuperar Contraseña</a>
				  </div>
				</div>
			</div>
		  </div>
