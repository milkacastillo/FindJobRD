<h4> Sobre nosotros </h4>


<p> Somos una empresa encargada de ofrecer servicios de internet, con el compromiso de encontrar soluciones para para empresas
como a diversos clientes en general </p>

<p2>La plataforma FindJob esta enfocada tanto a empresas como para personas interesadas en encontrar empleos. </p2>
<br/>
<br/>
