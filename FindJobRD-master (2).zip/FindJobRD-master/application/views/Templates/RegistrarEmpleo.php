<br>
<div class="container">
      <h3 style="color:#008B8B" ALIGN="center"> <b>Registrar Empleo</b></h3>
      <div class="row">

      </br>
           <form action="" method="post">
           <div class="col-md-12" >

            <div class="form-group input-group">
              <span class="input-group-addon"><b>Empresa:</b></span>
              <input class="form-control" name="Empresa" required="Empresa">
             </div>

             <div class="form-group input-group">
              <span class="input-group-addon"><b>Puesto:</b></span>
              <input class="form-control" name="Puesto" required="Puesto">
             </div>

             <div class="form-group input-group">
              <span class="input-group-addon"><b>Fecha:</b></span>
              <input class="form-control" name="Fecha" required="Fecha">
             </div>

              <div class="form-group input-group">
              <span class="input-group-addon"><b>Actividad</b></span>
              <input class="form-control" name="Actividad" required="Actividad">
              </div>

              <div class="form-group input-group">
              <span class="input-group-addon"><b>Area:</b></span>
              <input class="form-control" name="Area" required="Area">
              </div>

              <div class="form-group input-group">
              <span class="input-group-addon"><b>Pais:</b></span>
              <select class="list-group-item" name="Pais">
              <option value="">Seleccione País</option>
              <option>Republica Dominicana</option>
              </select>
              </div>
              <div class="form-group">
              <label for="comment"><b>Descripcion:</b></label>
              <textarea class="form-control" rows="5" id="Descripcion"></textarea>
             </div>


              <div class="form-group input-group">
              <span class="input-group-addon"><b>Dirección:</b></span>
              <input type="text" class="form-control" name="Direccion" required="Direccion">
              </div>

              <div class="form-group input-group">
              <span class="input-group-addon"><b>Jornada:</b></span>
              <select class="list-group-item" name="Pais">
              <option value="">Seleccione Jornada</option>
              <option>Tiempo Completo</option>
              <option>Medio Tiempo</option>
              <option>Jornada Parcial</option>
                </select>
              </div>
             <div class="form-group input-group">
              <span class="input-group-addon"><b>Beneficios:</b></span>
              <input type="text" class="form-control" name="Beneficios" required="Beneficios">
              </div>
              </div>
              <div class="form-group input-group">
              <span class="input-group-addon"><b>Salario:</b></span>
              <input type="text" class="form-control" name="Salario" required="Salario">
              </div>
              </div>

              <div class="form-group input-group">
              <span class="input-group-addon"><b>Solicitud:<b></span>
              <input type="text" class="form-control" name="Solicitudes" required="Solicitudes">
              </div>
              </div>
        </div>
      </form>
    </div>
</div>
</div>
</br>
<div class="text-center">
  <a type="submit" class="btn btn-primary">Registrar</a>
</div>
</br>
