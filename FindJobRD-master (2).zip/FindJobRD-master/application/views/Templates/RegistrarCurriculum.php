<br>
<div class="container">
      <h3 style="color:#008B8B"ALIGN="center"><b>Registrar Curriculum</b></h3></br>
      <div class="row">

      <form action="" method="post">
        <div class="col-md-12" >
          <div class="col-md-12">


            <div class="form-group input-group">
              <span class="input-group-addon">Usuario:</span>
            <input type="text" class="form-control" name="NombreUsuario" required="NombreUsuario">

              </div>
                <div class="form-group input-group">
                  <span class="input-group-addon">Email:</span>
                  <input type="text" class="form-control" name="Email" required="Email">
                </div>

            <div class="form-group input-group">
             <span class="input-group-addon">Contraseña:</span>
            <input type="text" class="form-control" name="Contrasena" required="Contrasena">
                </div>

            <div class="form-group input-group">
              <span class="input-group-addon">Nombre:</span>
              <input class="form-control" name="Nombre" required="Nombre">
            </div>

            <div class="form-group input-group">
              <span class="input-group-addon">Apellidos:</span>
              <input type="text" class="form-control" name="Apellido" required="Apellido">
            </div>
            <div class="form-group input-group">
              <span class="input-group-addon">Documento de identidad:</span>
              <input type="text" class="form-control" name="Cedula" required="Cedula" >
            </div>
            <div class="form-group input-group">
              <span class="input-group-addon">Cedula:</span>
              <input type="text" class="form-control" name="Cedula" required="Cedula" >
            </div>

            <div class="form-group input-group">
              <span class="input-group-addon">Teléfono Móvil:</span>
              <input type="text" class="form-control" name="Cedula" required="Cedula" >
            </div>
           <div>
            <label class="checkbox-inline"><input type="checkbox" value="">Hombre</label>
          <label class="checkbox-inline"><input type="checkbox" value="">Mujer</label>
        </div>


            <div class="form-group input-group">
              <span class="input-group-addon">Ciudad:</span>
              <select class="list-group-item" name="Ciudad">
                <option value="">Seleccione Ciudad</option>
                  <option>Santo Domingo</option>
              </select>
            </div>
            <div class="form-group input-group">
              <span class="input-group-addon">Pais:</span>
              <input type="text" class="form-control" name="Pais" required="Pais">
            </div>

            <div class="form-group input-group">
              <span class="input-group-addon">Dirección:</span>
              <input type="text" class="form-control" name="Direccion" required="Direccion">
            </div>

            <div class="form-group input-group">
              <span class="input-group-addon">Código Postal:</span>
              <input type="text" class="form-control" name="Direccion" required="Direccion">
            </div>

            <div class="form-group input-group">
              <span class="input-group-addon">Telefono:</span>
              <input type="text" class="form-control" name="Telefono" required="Telefono">
            </div>
            <div class="form-group input-group">
              <span class="input-group-addon">Fecha de nacimiento:</span>
              <input type="date" class="form-control" name="Telefono" required="Telefono">
            </div>
          <div>
                <div class="form-group input-group">
                    <span class="input-group-addon">Nacionalidad:</span>
              <td>&nbsp;</td>
              <td colspan="2"> <select name="nacionalidad">
                  <option value="República Dominicana" selected=""></option>
                  <option value="Alemania">Alemania</option>
                  <option value="Argentina">Argentina</option>
                  <option value="Australia">Australia</option>
                  <option value="Austria">Austria</option>
                  <option value="Barbados">Barbados</option>
                  <option value="Bélgica">Bélgica</option>
                  <option value="Belize">Belize</option>
                  <option value="Bermuda">Bermuda</option>
                  <option value="Bolivia">Bolivia</option>
                  <option value="Brasil">Brasil</option>
                  <option value="Bulgaria">Bulgaria</option>
                  <option value="Canadá">Canadá</option>
                  <option value="Chequia">Chequia</option>
                  <option value="Chile">Chile</option>
                  <option value="Chipre">Chipre</option>
                  <option value="Colombia">Colombia</option>
                  <option value="Costa Rica">Costa Rica</option>
                  <option value="Cuba">Cuba</option>
                  <option value="Dinamarca">Dinamarca</option>
                  <option value="Ecuador">Ecuador</option>
                  <option value="El Salvador">El Salvador</option>
                  <option value="Eslovaquia">Eslovaquia</option>
                  <option value="Eslovenia">Eslovenia</option>
                  <option value="España">España</option>
                  <option value="Estonia">Estonia</option>
                  <option value="Hungría">Hungría</option>
                  <option value="Europa">Europa</option>
                  <option value="Filipinas">Filipinas</option>
                  <option value="Finlandia">Finlandia</option>
                  <option value="Francia">Francia</option>
                  <option value="Grecia">Grecia</option>
                  <option value="Guatemala">Guatemala</option>
                  <option value="Guinea Ecuatorial">Guinea Ecuatorial</option>
                  <option value="Haiti">Haiti</option>
                  <option value="Honduras">Honduras</option>
                  <option value="Irlanda">Irlanda</option>
                  <option value="Italia">Italia</option>
                  <option value="Jamaica">Jamaica</option>
                  <option value="Letonia">Letonia</option>
                  <option value="Lituania">Lituania</option>
                  <option value="Luxemburgo">Luxemburgo</option>
                  <option value="Malta">Malta</option>
                  <option value="Marruecos">Marruecos</option>
                  <option value="México">México</option>
                  <option value="Nicaragua">Nicaragua</option>
                  <option value="Noruega">Noruega</option>
                  <option value="Países Bajos">Países Bajos</option>
                  <option value="Panamá">Panamá</option>
                  <option value="Paraguay">Paraguay</option>
                  <option value="Perú">Perú</option>
                  <option value="Polonia">Polonia</option>
                  <option value="Portugal">Portugal</option>
                  <option value="Puerto Rico">Puerto Rico</option>
                  <option value="Reino Unido">Reino Unido</option>
                  <option value="República Dominicana">República Dominicana</option>
                  <option value="Rumanía">Rumanía</option>
                  <option value="Saint Maarten">Saint Maarten</option>
                  <option value="Suecia">Suecia</option>
                  <option value="China">China</option>
                  <option value="Suiza">Suiza</option>
                  <option value="India">India</option>
                  <option value="Trinidad y Tobago">Trinidad y Tobago</option>
                  <option value="Taiwan">Taiwan</option>
                  <option value="Túnez">Túnez</option>
                  <option value="Turquía">Turquía</option>
                  <option value="Uruguay">Uruguay</option>
                  <option value="USA">USA</option>
                  <option value="Venezuela">Venezuela</option>
                  <option value="Otro">Otro</option>

                </select>
                <font color="#FF0000">*</font> </td>
          </div>
        </div>
          <div class="form-group input-group">
            <span class="input-group-addon">Página web:</span>
            <input type="text" class="form-control" name="Pgw" required="URL">
          </div>
            <div class="text-center">
              <button type="submit" class="btn btn-primary">Registrar Curriculum</button>
            </div>
        </div>
        </div>
      </form>
    </div>
</div>
</div>
</br>
</br>
