<h1 class="text-center"><b>Servicios</b></h1>


<div class="list-group">
    <a class="list-group-item active"class="text-center">
        Servicios para empresas
    <br/>
    </a>

    <a class="list-group-item">
       <li>  Revision de curriculums </li>
    </a>
    <a class="list-group-item">
       <li> Revision de Solucitudes<li/>
    </a>
    <a class="list-group-item active list-group-item-success">
       US$9 al mes.
    </a>
    </div>

<div class="list-group">
    <a class="list-group-item active">
        Posteo de Curriculums
    </a>
    <a class="list-group-item">
        <li>Candidatos</li>
    </a>
    <a class="list-group-item">
       <li> Contratistas</li>
    </a>
    <a class="list-group-item active list-group-item-success">
        US$2.99 al mes.
    </a>
    </div>


</div>
<br/>
<br/>
<h1 class="text-center"><b>Metodos de Pago</b></h1>
<hr class="featurette-divider">

<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div>
                <a href="https://www.paypal.com/do/webapps/mpp/home">
                    <h4>Paypal</h4>
                </a>
                </div>
            </div>
        <div class="col-md-4">
            <div>
                <a href="https://www.skrill.com/es/">
                    <h4>Skrill</h4>
                </a>
                </div>
            </div>
        <div class="col-md-4">
            <div>
                <a href="https://www.neteller.com/es">
                    <h4>Neteller</h4>
                </a>
                </div>
            </div>
        </div>
    </div>
<br/>
</br>
